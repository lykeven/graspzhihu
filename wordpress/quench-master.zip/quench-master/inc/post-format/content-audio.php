<article <?php post_class(); ?>>
    <div class="entry-music">
        <?php the_content('');?>
    </div>
</article>